package net.sid.springmvc.exception;

public class CustomException extends Exception {
	 
    private String message = "This is an exception..";
 
    public CustomException(String message) {
        this.message = message;
    }
 
    public String getMessage() {
        return message;
    }
 
    public void setMessage(String message) {
        this.message = message;
    }
}
