package net.sid.springmvc.dao;

import java.util.List;

import net.sid.springmvc.entity.Customer;

public interface AddressDAO {

	public List <Customer> getCustomerByPin (int pin);
	public List<Customer> getCustomerByCity (String city);
	
	
}