package net.sid.springmvc.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.*;

@Entity
@Table(name="Address")
public class Address {

@Id
@GeneratedValue(strategy=GenerationType.AUTO)
	
@Column(name = "street")
private String street;

@Column(name="city")
private String city;

@Column(name = "pin")
private int pin;

public String getStreet() {
	return street;
}

public void setStreet(String street) {
	this.street = street;
}

public String getCity() {
	return city;
}

public void setCity(String city) {
	this.city = city;
}

public int getPin() {
	return pin;
}

public void setPin(int pin) {
	this.pin = pin;
}


}
