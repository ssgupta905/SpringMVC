package net.sid.springmvc.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.*;

@Entity
@Table(name="Address")
public class Address {

@Id
@GeneratedValue(strategy=GenerationType.AUTO)
@Column(name="Id")
private int id;
	
@Column(name = "street")
private String street;

@Column(name="city")
private String city;

@Column(name = "pin")
private int pin;

@ManyToOne(cascade = CascadeType.ALL)
@JoinColumn(name="customer_id")
private Customer customer;




public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getStreet() {
	return street;
}

public void setStreet(String street) {
	this.street = street;
}

public String getCity() {
	return city;
}

public void setCity(String city) {
	this.city = city;
}

public int getPin() {
	return pin;
}

public void setPin(int pin) {
	this.pin = pin;
}

public Customer getCustomer() {
	return customer;
}

public void setCustomer(Customer customer) {
	this.customer = customer;
}

@Override
public String toString() {
	return "Address [id=" + id + ", street=" + street + ", city=" + city + ", pin=" + pin + ", customer=" + customer
			+ "]";
}

public Address(int id, String street, String city, int pin, Customer customer) {
	super();
	this.id = id;
	this.street = street;
	this.city = city;
	this.pin = pin;
	this.customer = customer;
} 



}
